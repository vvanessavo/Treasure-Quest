import java.lang.Math;
public class Main{
	
	public static void main(String[] args){
		
		ATMUserInterface ui = new ATMUserInterface();
    ATM atm = new ATM(ui);
    ui.setStartState();

    



  }


}

