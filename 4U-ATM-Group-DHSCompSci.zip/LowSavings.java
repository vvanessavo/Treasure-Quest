public class LowSavings extends Account{

  public LowSavings(int accountNum, int PIN, double balance){
    super(accountNum, PIN, balance, "l");
  }

  public double withdrawal(double balance, double withdrawal){
    double newBalance = balance - withdrawal;
    return newBalance;
  }
  public double deposit(double balance, double deposit){
    double total = balance + deposit;
    double total2 = total + (total*0.01);
    double newBalance = (double)Math.round(total2*100) / 100;
    return newBalance;
  }

  
}