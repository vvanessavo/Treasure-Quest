import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.Button;
import java.awt.Panel;
import java.awt.Frame;

/**	a component that lets the user enter a number, using a button pad labeled with digits
 */
public class KeyPad extends Panel{
	
	private Panel buttonPanel;
	private Button clearButton;
	private TextField display;
	
	public KeyPad(){
		setLayout(new BorderLayout());
		
		//add display field
		display = new TextField();
		add(display, "North");
		
		//make button panel
		
		buttonPanel = new Panel();
		buttonPanel.setLayout(new GridLayout(4,3));
		
		//add digit buttons
		ActionListener listener = new DigitButtonListener();
		
		addButton("7",listener);
		addButton("8",listener);
		addButton("9",listener);
		addButton("4",listener);
		addButton("5",listener);
		addButton("6",listener);
		addButton("1",listener);
		addButton("2",listener);
		addButton("3",listener);
		addButton("0",listener);
		addButton(".",listener);
		
		//add clear entry button
		clearButton = new Button("CE");
		buttonPanel.add(clearButton);
		clearButton.addActionListener(new ClearButtonListener());
		add(buttonPanel, "Center");
		
		
	}
	
	
	/**	gets the value that the user entered
	 *	@return the value in the text field of the keypad
	 */
	 public double getValue(){
	 	return Double.parseDouble(display.getText());
	 }
	 
	/**	Clears the display
	 */
	 public void clear(){
	 	display.setText("");
	 }
	 /*************************************************************************
	  *	You will not need to worry about the code below here
	  */
	 
	/**	adds a button to the panel
	 *	@param label the button label
	 *	@param listener the button listener
	 */
	 public void addButton(String label, ActionListener listener){
	 	Button button = new Button(label);
	 	buttonPanel.add(button);
	 	button.addActionListener(listener);
	 	
	 }
	 
	 private class DigitButtonListener implements ActionListener{
	 	public void actionPerformed(ActionEvent event){
	 		//get the button label
	 		//it is a digit or decimal point
	 		Button source = (Button)event.getSource();
	 		String label = source.getLabel();
	 		
	 		//don't add two decimal points
	 		if(label.equals(".") && display.getText().indexOf(".") != -1){
	 			return;
	 		}
	 		
	 		display.setText(display.getText() + label);
	 	}
	 }
	 
	 private class ClearButtonListener implements ActionListener{
	 	public void actionPerformed(ActionEvent event){
	 		clear();
	 		
	 	}
	 }
}
