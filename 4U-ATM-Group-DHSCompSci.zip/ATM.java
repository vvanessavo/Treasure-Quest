import java.util.*;
import java.io.*;
/**	this class holds all the rules for using the ATM. Specifically, this class will have
 *	to determine what should happen when a button is pushed.
 */
public class ATM extends Object{

	/**	the ATM has a reference to the Userinterface class. The goal of this, is to
	 *	allow the ATM to tell the userinterface what to do and when.*/
	private ATMUserInterface ui; 


  /**We will keep track of the ATM state by using an integer named state.
    See the assignment sheet for more info
    */
  //fields
  private int state = 0;
  public Account currentAccount;
  Account x = null; 
  ArrayList<Account> account = new ArrayList<>();

	public ATM(ATMUserInterface ui){
		//assign the passed userinterface to our instance variable.
		this.ui = ui;

    try (BufferedReader br = new BufferedReader(new FileReader
    ("accounts.txt"))) {
      String line;
      while ((line = br.readLine()) != null) {
        String[] values = line.split(" ");
        int accountNum = Integer.parseInt(values[0]);
        int PIN = Integer.parseInt(values[1]);
        double balance = Double.parseDouble(values[2]);
        String accountType = values[3];
        
        account.add(new Account(accountNum, PIN, balance, accountType));

        if(accountType.equals("b")){
          account.add(new Basic(accountNum, PIN, balance));
        }
        else if(accountType.equals("l")){
          account.add(new LowSavings(accountNum, PIN, balance));
        }
         if(accountType.equals("h")){
          account.add(new HighSavings(accountNum, PIN, balance));
        }
        
    }
     
    } catch (Exception e) {
      System.out.println("Whooops1");
      System.out.println(e.getMessage());
    }

  }
   
  /**	ACCOUNT button was pushed in the userinterface and your logic must determine what 
	*	to do about it.
	*/
  
  public void accountButtonClicked(){
	 	//The code below is the start of some code you may find useful
     if(this.state == 0)
     {  //we are at the start state
        //Save the id entered into the keypad to accountNum
        int accNum = this.ui.getKeyPadInt();
        
        //looped through the array to find if one of the account numbers matched accountNum
        for(Account a: account){
          if(a.accountNum == accNum){
            this.ui.clearDisplay();
            this.ui.setPINState();
            this.state = 1;
            currentAccount = new Account(a.accountNum, a.PIN, a.balance, a.accountType);
            x = a;
          }
          else{
            this.ui.clearDisplay();
            this.ui.setPINState();
          }
        }
      }
	}
  
  /**	PIN button was pushed in the userinterface and your logic must determine what 
	  *	to do about it.
	  */
  public void pinButtonClicked(){

    int PINNum = this.ui.getKeyPadInt();
    if(this.state == 1){
      if(x.PIN == PINNum){
        this.ui.clearDisplay();
        this.state = 2;
        this.ui.setTransactState();
      }
      else {
        this.ui.clearDisplay();
        this.ui.setStartState();
        this.state = 0;
      }
    }
    else if(this.state == 0) {
      this.ui.clearDisplay();
      this.ui.setStartState();
    }    
	}
  /**	DEPOSIT button was pushed in the userinterface and your logic must determine what 
	*	to do about it.
	*/
  public void depositButtonClicked(){
    double depAmount = this.ui.getKeyPadInt();
    double newBalance;
    if(this.state == 2){

      if(x.accountType.equals("b")){
        newBalance = x.deposit(x.balance, depAmount);
        this.ui.setDisplay("Deposit made successfully.\nBalance = $"+String.valueOf(newBalance));
      }
      else if(x.accountType.equals("l")){
        newBalance = x.deposit(x.balance, depAmount);
        this.ui.setDisplay("Deposit made successfully.\nBalance = $" + String.valueOf(newBalance));
      }
      else if(x.accountType.equals("h")){
        newBalance = x.deposit(x.balance,depAmount);
        this.ui.setDisplay("Deposit made successfully.\nBalance = $"+String.valueOf(newBalance));
      }
    }
	 	
	}
  /**	WITHDRAW button was pushed in the userinterface and your logic must determine what 
	  *	to do about it.
	  */
  public void withdrawButtonClicked(){
    double witAmount = this.ui.getKeyPadInt();
    double newBalance;
    if(this.state == 2){
      if(x.accountType.equals("b")){
        newBalance = x.withdrawal(x.balance, witAmount);
        this.ui.setDisplay("Withdrawal made successfully.\nBalance = $"+String.valueOf(newBalance));
      }
      else if(x.accountType.equals("l")){
        newBalance = x.withdrawal(x.balance,witAmount);
        this.ui.setDisplay("Withdrawal made successfully, \nBalance = $" + String.valueOf(newBalance));
      }
      else if(x.accountType.equals("h")){
        newBalance = x.withdrawal(x.balance,witAmount);
        this.ui.setDisplay("Withdrawal made successfully.\nBalance = $"+String.valueOf(newBalance));
      }
    }	
	}

 /**	QUIT button was pushed in the userinterface and your logic must determine what 
	  *	to do about it.
	  */
  public void quitButtonClicked(){
	 	this.state = 0;
    this.ui.clearDisplay();
    this.ui.setStartState();
	}

}