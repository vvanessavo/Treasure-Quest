public class HighSavings extends Account{

  public HighSavings(int accountNum, int PIN, double balance){
   super(accountNum, PIN, balance, "h");
  }

  public double withdrawal(double balance, double withdrawal){
    double newBalance = balance - withdrawal - 10.00;
    return newBalance;
  }
  public double deposit(double balance, double deposit){
    double total = balance + deposit;
    double total2 = total + (total*0.05);
    double newBalance = (double)Math.round(total2*100)/100;
    return newBalance;
    
  }


  
}