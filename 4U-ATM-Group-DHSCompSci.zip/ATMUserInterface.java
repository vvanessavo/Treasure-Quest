import javax.swing.JFrame;
import java.io.IOException;
import java.awt.Button;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.Container;

/**	this class is the userinterface for our simulation. Interaction between the ATM (Rules)
 *	class and this class will occur. But, this class will not interact any class other 
 *	than ATM and KeyPad. 
 */ 
public class ATMUserInterface extends JFrame{
	
	
	private ATM theATM; 
	
	//the buttons to be used in the frame
  private Button accountButton;
  private Button pinButton;
  private Button depositButton;
  private Button withdrawButton;
  private Button quitButton;
	
	//an instance of our keypad class
	private KeyPad pad;
	
	//an instance of the textarea
	private TextArea display;
	
	
	/**	Constructor to create the user interface. 
	 */
	public ATMUserInterface(){
		
		final int FRAME_WIDTH = 500;
		final int FRAME_HEIGHT = 200;
		
		this.setSize(FRAME_WIDTH, FRAME_HEIGHT);//set the size of the frame
		
		addWindowListener(new WindowCloser());
		
		//create the ATM which controls the rules of the program
		theATM = new ATM(this);
	
	
		//create components. You will not have to worry about the items below.
		//but you will need to know the methods below. 
		pad = new KeyPad();
		
		display = new TextArea(4, 20);

    accountButton = new Button("ACCOUNT");
		accountButton.addActionListener(new accountButtonListener());

    pinButton = new Button("PIN");
		pinButton.addActionListener(new pinButtonListener());

    withdrawButton = new Button("WITHDRAW");
		withdrawButton.addActionListener(new withdrawButtonListener());

    depositButton = new Button("DEPOSIT");
		depositButton.addActionListener(new depositButtonListener());

    quitButton = new Button("QUIT");
		quitButton.addActionListener(new quitButtonListener());
		
		//add components to content pane
    Panel button2Panel = new Panel();
		button2Panel.setLayout(new GridLayout(2,2));
		button2Panel.add(accountButton);
		button2Panel.add(pinButton);
		button2Panel.add(withdrawButton);
    button2Panel.add(depositButton);
    button2Panel.add(quitButton);
		
		Container contentPane = getContentPane();
		contentPane.setLayout(new FlowLayout());
		contentPane.add(pad);
		contentPane.add(display);
    contentPane.add(button2Panel);
		
		this.setResizable(false);
		this.show();
		
	}
	

	/**	sets the textArea for the display
	 */	
	 public void setDisplay(String text){
	 	this.display.setText (text);
	 }

   	/**	gets the textArea for the display
	 */	
	 public String getDisplay(){
	 	return this.display.getText();
	 }
	 

	/**	gets the integer value from the keypad display
	 *	@return the value in the display
	 */	
	 public int getKeyPadInt(){
	 	return (int)pad.getValue();
	 }
	 
	/**	the userinterface will clear the diplay so that nothing is in the text area
	 */
	 public void clearDisplay(){
	 	pad.clear();
	 }
	 
	 /**	Tell the userinterface to display the Start State. The ATM class will 
	  *		this method. */
	 public void setStartState(){
	 	display.setText("Enter customer number\nACCOUNT = OK");
	 }
	 
	 /**	Tell the userinterface to display the PIN state. The ATM class will 
	  *		this method. */
	 public void setPINState(){
	 	display.setText("Enter PIN\nPIN = OK");
	 }
	 
	 
	/**	sets the text area to display the options when in the transaction state. 
	 *	This method is not completed....you may or may not use this
	 */
	 public void setTransactState(){
	 	display.setText("Enter an amount and press a transaction.\nPress quit to end.\nBalance = $" + this.theATM.x.balance);
	 }
	 
	 
	/**	The code below is needed to tell the ATM Class that a button has been pushed
	 *	you will not need to modify this code below. You will not need to understand 
	 *	how it works.....just that it is needed is good enough
	 */

  private class accountButtonListener implements ActionListener{
	 	public void actionPerformed(ActionEvent event){
	 		theATM.accountButtonClicked();
	 	}
	 }

  private class pinButtonListener implements ActionListener{
	 	public void actionPerformed(ActionEvent event){
	 		theATM.pinButtonClicked();
	 	}
	 }

  private class withdrawButtonListener implements ActionListener{
	 	public void actionPerformed(ActionEvent event){
	 		theATM.withdrawButtonClicked();
	 	}
	 }

  private class depositButtonListener implements ActionListener{
	 	public void actionPerformed(ActionEvent event){
	 		theATM.depositButtonClicked();
	 	}
	 }

  private class quitButtonListener implements ActionListener{
	 	public void actionPerformed(ActionEvent event){
	 		theATM.quitButtonClicked();
	 	}
	 }
	 
	 private class WindowCloser extends WindowAdapter{
	 	public void windowClosing(WindowEvent event){
	 		System.exit(0);
	 	}
	 }
	
	
}
