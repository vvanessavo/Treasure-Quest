import java.util.Scanner;
public class Account{
  public int accountNum;
  public int PIN;
  public double balance;
  public String accountType;

  public Account(int accountNum, int PIN, double balance, String accountType){
    this.accountNum = accountNum;
    this.PIN = PIN;
    this.balance = balance;
    this.accountType = accountType; 
  }

  public double withdrawal(double balance, double withdrawal){
   return balance;
  }

  public double deposit(double balance, double deposit){
    return balance;
  }

  public int getAccountNum(){
    return this.accountNum;
  }
  public double getbalance(){
    return this.balance;
  }
  public int getPIN(){
    return this.PIN;
  }
  public String getAccountType(){
    return this.accountType;
  }
  public void setAccountNum(int accountNum){
    this.accountNum = accountNum;
  }
  public void setBalance(double balance){
    this.balance = balance;
  }
  public void setPIN(int PIN){
    this.PIN = PIN;
  }
  public void setAccountType(String accountType){
    this.accountType = accountType;
  }
  public String toString(){
    return "\nAccount Number: " + this.accountNum +"\nPIN: "+this.PIN + "\nBalance: "+this.balance+"\nAccount Type: "+this.accountType+ "\n";
  }
}