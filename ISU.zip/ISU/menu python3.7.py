#**********************************************************
# Program : Pygame game
# Author : Vanessa Vo
# Due Date : 11/28/18
# Description : menu screen 
#**********************************************************


##Window
import pygame
import sys
from pygame.locals import*
pygame.init()

FPS = 40
fpsClock = pygame.time.Clock()

Window = pygame.display.set_mode((600,600))

##Colours

white = 255,255,255

black = 0,0,0

red = 230,0,0

##Background

Window.fill

bg = pygame.image.load("green.jpg")

Window.blit(bg,(0,0))

##Title

font = pygame.font.SysFont("Lobster Two",100,True,False)

text = font.render("Treasure Quest", True, red)

Window.blit(text,(0,120))

##Tutorial

In = pygame.image.load("button_tutorial.png")

Window.blit(In,(20,250))

##Level 1 button

L1 = pygame.image.load("button_level1.png")

Window.blit(L1,(220,250))

##Level 2 button

L2 = pygame.image.load("button_level2.png")

Window.blit(L2,(220,350))                   

##Level 3 button

L3 = pygame.image.load("button_level3.png")

Window.blit(L3,(220,450))

#Game Loop

while True:

    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit

        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse =(("%d,%d")%event.pos)
            a,b = mouse.split(",")
            a = int(a)
            b=int(b)
            print(a)
            print(b)
            position = pygame.mouse.get_pos()
            print(position)

            if a>210 and b>270 and a<415 and b<334:
                exec(open("ISU.level1.py").read())

            if a>210 and b>340 and a<413 and b<436:
                exec(open("ISU.level2.py").read())

            if a>210 and b>470 and a<415 and b<535:
                exec(open("ISU.level3.py").read())

            if a>20 and b>250 and a<185 and b<320:
                exec(open("ISU.tutorial.py").read())

    pygame.display.update()
    fpsClock.tick(FPS)
        


