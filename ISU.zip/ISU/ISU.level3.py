#**********************************************************
# Program : Pygame game level 3
# Author : Vanessa Vo
# Due Date : 11/28/18
# Description : pygame
#**********************************************************


##Window
import pygame
import sys
from pygame.locals import*
pygame.init()

FPS = 40
velx = 4
fpsClock = pygame.time.Clock()

Window = pygame.display.set_mode((600,600))

##pygame.display.set_caption("

## COLOURSSS

beige = 199, 155, 112
black = 0,0,0
white= 255,255,255

##Background
Window.fill

bg = pygame.image.load("green.jpg")

Window.blit(bg,(0,0))

pygame.draw.rect(Window,beige,(0,550,600,20))

pygame.draw.rect(Window,beige,(0,390,400,20))

pygame.draw.rect(Window,beige,(550,390,50,20))

pygame.draw.rect(Window,beige,(0,220,450,20))

pygame.draw.rect(Window,beige,(0,220,290,20))



pygame.display.update()

##Characters

#Right images
image = []

image.append(pygame.image.load("right.png"))
image.append(pygame.image.load("right.png"))
image.append(pygame.image.load("right.png"))
image.append(pygame.image.load("right.png"))


#left images
left = []

left.append(pygame.image.load("left.png"))
left.append(pygame.image.load("left.png"))
left.append(pygame.image.load("left.png"))
left.append(pygame.image.load("left.png"))

x = 0

y = 150

index = 0
pic = image[0]

##Bad Guyy 1

bad =[]

bad.append(pygame.image.load("enemy.png"))

picture = bad[0]

enemyx = 40

enemyy = 515

##Bad Guyy 2

bad2 =[]

bad2.append(pygame.image.load("enemy.png"))

picture = bad2[0]

enemy2x = 40

enemy2y = 355

##Bad Guyy 3

bad3 =[]

bad3.append(pygame.image.load("enemy.png"))

picture = bad3[0]

enemy3x = 250

enemy3y = 515

##Bad guy 4

bad4 =[]

bad4.append(pygame.image.load("enemy.png"))

picture = bad4[0]

enemy4x = 150

enemy4y = 185

##Variables

upPushed = False
gem = True
gem2 = True
jewl3 = True
notDead = False 
spikes =True
text = False
wall =True
finish = False
game = True

##Images

menu = pygame.image.load("button_menu.png")
TA = pygame.image.load("button_try-again.png")
jewl2 = pygame.image.load("smalldiamond.png")

##Gameloop
while not finish :
    if notDead == False:


        keys = pygame.key.get_pressed()
        #IF the user quits
        for event in pygame.event.get():
            
            if event.type == QUIT:
                
                pygame.quit()
                
                sys.exit()

        #IF they press up button

        if keys[pygame.K_UP]:
                
                if not upPushed: 
                    
                    upPushed = True

                    y = y - 75

        #Jump and go right

        if  keys[pygame.K_UP] and keys[pygame.K_RIGHT]:

            if y+2<600 and x+2<600:

                if (wall == False):

                    x = x +10

                    index = index +1

                    if (index >3):
                          
                        index = 0
                      
                    pic = image[index]

                else:
                    
                    if x < 430 or y < 410:
                        
                        x = x + 10
                 
                        index = index +1

                        if (index >3):

                            index = 0

                        pic = image[index]

            if not upPushed:

                upPushed = True

                y = y - 75

        #Jump and go left

        if  keys[pygame.K_UP] and keys[pygame.K_LEFT]:

            if y+2<600 and x+2<600:
            
                x = x -10

                index = index +1

                if (index >3):
                      
                    index = 0
                      
                pic = left[index]

            if not upPushed:

                upPushed = True

                y = y- 75
        
        #IF user presses right
                
        elif keys[pygame.K_RIGHT]:

            if x+10<=535:

                if (wall == False):
            
                    x = x + 10

                    index = index +1
                    
                    if (index >3):
                        
                        index = 0

                    pic = image[index]

                else:
                    
                    if x < 430 or y < 410:
                        
                        x = x + 10
                 
                        index = index +1

                        if (index >3):

                            index = 0

                        pic = image[index]

                    

        #IF users preses left
                
        elif keys[pygame.K_LEFT]:

            if x-10>=0 :
            
                x = x -  10
         
                index = index +1

                if (index >3):

                    index = 0

                pic = left[index]

        ##Collision Detection variables

        done = False

        clock = pygame.time.Clock()

        rect1 = pygame.Rect(0,550,600,20)

        rect2 = pygame.Rect(0,390,380,20)

        rect3 = pygame.Rect(490,390,110,20)

        rect4 = pygame.Rect(0,220,450,20)

        rect5 = pygame.Rect(0,220,290,20)

        recChar = pygame.Rect(x+3,y+10,66,47)
        
        Window.blit(bg,(0,0))
         
        pygame.draw.rect(Window,beige,(0,550,600,20))

        pygame.draw.rect(Window,beige,(0,390,380,20))

        pygame.draw.rect(Window,beige,(490,390,110,20))

        pygame.draw.rect(Window,beige,(0,220,450,20))

        pygame.draw.rect(Window,beige,(0,220,290,20))

        ##boarder around         

        pygame.draw.rect(Window,beige,(0,0,600,1))

        pygame.draw.rect(Window,beige,(600,0,600,1))

        pygame.draw.rect(Window,beige,(0,600,600,1))

        pygame.draw.rect(Window,beige,(0 ,0,1,600))
        


                #Collision detection

        if recChar.colliderect(rect1):
            #Do nothing

            upPushed = False

        elif recChar.colliderect(rect2):
            #Do nothing

            upPushed = False

        elif recChar.colliderect(rect3):
            #Do nothing

            upPushed = False

        elif recChar.colliderect(rect4):
            #Do nothing
            
            upPushed = False

        elif recChar.colliderect(rect5):
            #Do nothing
                
            upPushed = False

        else:
            y = y + 5
            

##button pressing

    for event in pygame.event.get():

        if event.type == QUIT:
            
            pygame.quit()
            
            sys.exit()

        if event.type == pygame.MOUSEBUTTONDOWN :

            mouse =(("%d,%d")%event.pos)
            
            a,b = mouse.split(",")
            a = int(a)
            b=int(b)
            print(a)
            print(b)
            position = pygame.mouse.get_pos()
            print(position)

            if a>0 and b>0 and a<125 and b<40:
                
                exec(open("ISU.level3.py").read())

            if a>0 and b>55 and a<125 and b<90:
                
                exec(open("menu python3.7.py").read())


##Treasure chest

    treasure = pygame.image.load("treasure.png")

    rectreasure = pygame.Rect(535,505,70,70)

    Window.blit(treasure,(535,505))

    if (treasure):
        Window.blit(treasure,(535,505))

    if recChar.colliderect(rectreasure):

        font = pygame.font.SysFont("Arial", 100,True,False)

        text = font.render("You Won!!!",True,white)

        Window.blit(text,(100,200))

        notDead = True

        end = False

        velx = 0

    ##Middle left diamond

    jewl = pygame.image.load("diamond.png")

    recjewl= pygame.Rect(0,345,50,50)

    if (gem):
        
        Window.blit(jewl,(0,345))

    if (gem) == False:
        
        jewl3 = False 

    if recChar.colliderect(recjewl) :
    
        gem = False

    ##Middle right diamond

    recjewl2 = pygame.Rect(0,505,50,50)

    if (gem2):
        
        Window.blit(jewl,(0,505))
    
    if recChar.colliderect(recjewl2) and gem == False:
        
        gem2 = False
        
        wall = False 

    if (wall):
        
        pygame.draw.rect(Window,black,(500,410,20,140))

        Window.blit(jewl2,(500,490))
        
        rect5 = pygame.Rect(135,450,20,100)
            
    if (jewl3):

        Window.blit(jewl2,(500,450))

    ##Spikes

    spike= pygame.image.load("spike2.png")

    ##Spike 1

    recspike1 = pygame.Rect(129,188,5,30)

    recspike11=pygame.Rect(114,215,33,5)

    ##Spike 2
    
    recspike2 = pygame.Rect(418,188,5,30)

    recspike22 = pygame.Rect(403,215,33,5)

    ##Spike3

    recspike3 =pygame.Rect(258,518,5,30)

    recspike33 = pygame.Rect(243,545,33,5)

    ##Spike 4

    recspike4 = pygame.Rect(478,518,5,30)
    
    recspike44 = pygame.Rect(463,545,33,5)

    ##Spike 5

    recspike5 = pygame.Rect(258,358,5,30)

    recspike55 = pygame.Rect(243,385,33,5)

    if (spike):

        ##Spike1(top left)
        Window.blit(spike,(111,185))

        ##Spike2(top right)
        Window.blit(spike,(400,185))

        ##Spike3(bottem left)
        Window.blit(spike,(240,515))

        ##Spike4(bottem right)
        Window.blit(spike,(460,515))

        ##Spike5 (middle)
        Window.blit(spike,(240,355))

##        pygame.draw.rect(Window,white,(258,358,5,30))
##        
##        pygame.draw.rect(Window,white,(243,385,33,5))


    if recChar.colliderect(recspike1)or recChar.colliderect(recspike11):

        notDead = True

        font = pygame.font.SysFont("Arial", 100,True,False)

        text = font.render("You Lost :(",True,black)

        Window.blit(text,(100,200))

        velx = 0

    elif recChar.colliderect(recspike2) or recChar.colliderect(recspike22):
        notDead = True

        font = pygame.font.SysFont("Arial", 100,True,False)

        text = font.render("You Lost :(",True,black)

        Window.blit(text,(100,200))

        velx = 0
        
    elif recChar.colliderect(recspike3) or recChar.colliderect(recspike33):
        notDead = True

        font = pygame.font.SysFont("Arial", 100,True,False)

        text = font.render("You Lost :(",True,black)

        Window.blit(text,(100,200))

        velx = 0

    elif recChar.colliderect(recspike4) or recChar.colliderect(recspike44):
        notDead = True

        font = pygame.font.SysFont("Arial", 100,True,False)

        text = font.render("You Lost :(",True,black)

        Window.blit(text,(100,200))

        velx = 0

    elif recChar.colliderect(recspike5) or recChar.colliderect(recspike55):
        notDead = True 
        
        font = pygame.font.SysFont("Arial", 100,True,False)

        text = font.render("You Lost :(",True,black)

        Window.blit(text,(100,200))

        velx = 0

##Moving enemy

    ##Enemy at the bottem left

    if (enemyx+velx>200):
        velx = -3
    if (enemyx+velx<40):
        velx = 3

    enemyx = enemyx+velx;

    recenemy= pygame.Rect(enemyx+7,enemyy+3,30,30)

    if recChar.colliderect(recenemy):

        notDead = True

        font = pygame.font.SysFont("Arial", 100,True,False)

        text = font.render("You Lost :(",True,black)

        Window.blit(text,(100,200))

        velx = 0

    ##Enemy middle

    if (enemy2x+velx>200):
        velx = -4
    if (enemy2x+velx<40):
        velx =4

    enemy2x = enemy2x+velx;

    recenemy2= pygame.Rect(enemy2x+7,enemy2y+3,30,30)

    if recChar.colliderect(recenemy2):

        notDead = True

        font = pygame.font.SysFont("Arial", 100,True,False)

        text = font.render("You Lost :(",True,black)

        Window.blit(text,(100,200))

        velx = 0

    ##Enemy bottem right

    if (enemy3x+velx>430):
        velx = -3
        
    if (enemy3x+velx<270):
        velx =3

    enemy3x = enemy3x+velx;

    recenemy3= pygame.Rect(enemy3x+7,enemy3y+3,30,30)

    if recChar.colliderect(recenemy3):

        notDead = True

        font = pygame.font.SysFont("Arial", 100,True,False)

        text = font.render("You Lost :(",True,black)

        Window.blit(text,(100,200))

        velx = 0

    ##Enemy top

    if (enemy4x+velx>340):
        velx = -3
        
    if (enemy4x+velx<180):
        velx =3

    enemy4x = enemy4x+velx;

    recenemy4= pygame.Rect(enemy4x+7,enemy4y+3,30,30)

    if recChar.colliderect(recenemy4):

        notDead = True

        font = pygame.font.SysFont("Arial", 100,True,False)

        text = font.render("You Lost :(",True,black)

        Window.blit(text,(100,200))

        velx = 0


    ##Blitting stuff
        
    Window.blit(TA,(0,0))
    Window.blit(menu,(0,50))       
    Window.blit(bad[0],(enemyx,enemyy))
    Window.blit(bad2[0],(enemy2x,enemy2y))
    Window.blit(bad3[0],(enemy3x,enemy3y))
    Window.blit(bad4[0],(enemy4x,enemy4y))
    Window.blit(pic,(x,y))
    pygame.display.update()
    fpsClock.tick(FPS)

            

        


