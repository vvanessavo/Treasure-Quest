
import math 


number = int(input("Please enter a number :"))

letter = input("Please enter a letter :")

print(chr(ord(letter)+number))

             
