#**********************************************************
# Program : Pygame game level 1
# Author : Vanessa Vo
# Due Date : 11/28/18
# Description : pygame
#**********************************************************


##Window
import pygame
import sys
from pygame.locals import*
pygame.init()

FPS = 40
velx = 3
fpsClock = pygame.time.Clock()

Window = pygame.display.set_mode((600,600))

pygame.display.set_caption("Level 1")

## COLOURSSS

beige = 199, 155, 112
black = 0,0,0
white= 255,255,255

##Background
Window.fill

bg = pygame.image.load("green.jpg")

Window.blit(bg,(0,0))

pygame.draw.rect(Window,beige,(0,550,600,20))

pygame.draw.rect(Window,beige,(300,200,300,20))

pygame.draw.rect(Window,beige,(170,300,80,20))

pygame.draw.rect(Window,beige,(0,450,200,20))

pygame.display.update()

##Characters

#Right images Good guy
image = []

image.append(pygame.image.load("right.png"))
image.append(pygame.image.load("right.png"))
image.append(pygame.image.load("right.png"))
image.append(pygame.image.load("right.png"))


#left images Good guy
left = []

left.append(pygame.image.load("left.png"))
left.append(pygame.image.load("left.png"))
left.append(pygame.image.load("left.png"))
left.append(pygame.image.load("left.png"))

x = 500

y = 125

index = 0
pic = left[0]

##Bady gugyy

bad = []

bad.append(pygame.image.load("enemy.png"))

picture = bad[0]

enemyx =300

enemyy = 515

##Variables

upPushed = False
gem = True
notDead = False 
spikes =True
text = False
wall =True
finish = False
game = True

##Images

menu = pygame.image.load("button_menu.png")
TA = pygame.image.load("button_try-again.png")
nextt = pygame.image.load("button_next-level.png")

##Gameloop
while not finish :
    if notDead == False:

        keys = pygame.key.get_pressed()
        #IF the user quits
        for event in pygame.event.get():
            
            if event.type == QUIT:
                
                pygame.quit()
                
                sys.exit()

        #IF they press up button

        if keys[pygame.K_UP]:
                
                if not upPushed: 
                    
                    upPushed = True

                    y = y - 85

        #Jump and go right

        if  keys[pygame.K_UP] and keys[pygame.K_RIGHT]:

            if y+2<600 and x+2<600:
            
                x = x +10

                index = index +1

                if (index >3):
                      
                    index = 0
                      
                pic = image[index]

            if not upPushed:

                upPushed = True

                y = y - 85

        #Jump and go left

        if  keys[pygame.K_UP] and keys[pygame.K_LEFT]:

            if y+2<600 and x+2<600:
            
                x = x -10

                index = index +1

                if (index >3):
                      
                    index = 0
                      
                pic = left[index]

            if not upPushed:

                upPushed = True

                y = y- 85
        
        #IF user presses right
                
        elif keys[pygame.K_RIGHT]:

            if x+10<=535: 
            
                x = x + 10

                index = index +1
                
                if (index >3):
                    
                    index = 0

                    pic = image[index]

        #IF users preses left
                
        elif keys[pygame.K_LEFT]:

            if x-10>=0 :

                if (wall == False):
            
                    x = x -  10
             
                    index = index +1

                    if (index >3):

                        index = 0

                    pic = left[index]
                    
                else:

                    if (x > 159 or y < 460):    
                        x = x -  10
                 
                        index = index +1

                        if (index >3):

                            index = 0

                        pic = left[index]
                    
                    

        #Collision Detection variables

        done = False

        clock = pygame.time.Clock()

        rect1= pygame.Rect(0,550,600,20)

        rect2= pygame.Rect(280,200,320,20)

        rect3= pygame.Rect(170,300,80,20)

        rect4=pygame.Rect(0,450,155,20)

        recChar = pygame.Rect(x+3,y+10,66,47)

        Window.blit(bg,(0,0))

        pygame.draw.rect(Window,beige,(0,550,600,20))

        pygame.draw.rect(Window,beige,(280,200,320,20))

        pygame.draw.rect(Window,beige,(170,300,80,20))

        pygame.draw.rect(Window,beige,(0,450,155,20))


            #Collision detection

        if recChar.colliderect(rect1):
            #Do nothing

            upPushed = False

        elif recChar.colliderect(rect2):
            #Do nothing

            upPushed = False

        elif recChar.colliderect(rect3):
            #Do nothing

            upPushed = False

        elif recChar.colliderect(rect4):
            #Do nothing
            
            upPushed = False

        else:
            y = y + 5

##button pressing

    for event in pygame.event.get():

        if event.type == QUIT:
            
            pygame.quit()
            
            sys.exit()

        if event.type == pygame.MOUSEBUTTONDOWN :

            mouse =(("%d,%d")%event.pos)
            
            a,b = mouse.split(",")
            
            a = int(a)
            b=int(b)
            print(a)
            print(b)
            position = pygame.mouse.get_pos()
            print(position)

            if a>0 and b>0 and a<125 and b<40:
                
                exec(open("ISU.level1.py").read())

            if a>0 and b>55 and a<125 and b<90:
                
                exec(open("menu python3.7.py").read())

            if a>0 and b>110 and a<125 and b<140:

                exec(open("ISU.level2.py").read())


##Treasure chest
    treasure = pygame.image.load("treasure.png")

    rectreasure = pygame.Rect(0,505,70,70)

    Window.blit(treasure,(0,505))

    if (treasure):
        Window.blit(treasure,(0,505))

    if recChar.colliderect(rectreasure):

        font = pygame.font.SysFont("Arial", 100,True,False)

        text = font.render("You Won!!!",True,white)

        Window.blit(text,(100,200))

        notDead = True

        end = False

        velx = 0

##Diamonds

    jewl = pygame.image.load("diamond.png")

    recjewl= pygame.Rect(500,500,50,50)

    if (gem):
        Window.blit(jewl,(500,500))

    if recChar.colliderect(recjewl):
        
        gem = False

        wall = False 

    if (wall):
        
        pygame.draw.rect(Window,black,(135,470,20,80))

        jewl2 = pygame.image.load("smalldiamond.png")

        Window.blit(jewl2,(135,490))
        
        rect5 = pygame.Rect(135,450,20,100)
                
##Spikes

    spike= pygame.image.load("spike2.png")

    ##Spike 1

    recspike1 = pygame.Rect(190,265,5,30)

    recspike11=pygame.Rect(175,295,30,5)

    ##Spike 2
    
    recspike2 = pygame.Rect(230,270,5,30)

    recspike22 = pygame.Rect(215,295,30,5)

    ##Spike3

    recspike3 =pygame.Rect(118,418,5,30)

    recspike33 = pygame.Rect(104,445,32,5)

    ##Spike 4

    recspike4 = pygame.Rect(417,519,5,30)
    
    recspike44 = pygame.Rect(403,545,33,5)               

    if (spike):

        ##Spike1
        Window.blit(spike,(170,265))

        ##Spike2
        Window.blit(spike,(211,265))

        ##Spike3
        Window.blit(spike,(100,415))

        ##Spike4
        Window.blit(spike,(400,515))

##        pygame.draw.rect(Window,white,(417,519,5,30))
##        
##        pygame.draw.rect(Window,white,(403,545,33,5))


    if recChar.colliderect(recspike1)or recChar.colliderect(recspike11):

        notDead = True

        font = pygame.font.SysFont("Arial", 100,True,False)

        text = font.render("You Lost :(",True,black)

        Window.blit(text,(100,200))

        velx = 0

    elif recChar.colliderect(recspike2) or recChar.colliderect(recspike22):
        notDead = True

        font = pygame.font.SysFont("Arial", 100,True,False)

        text = font.render("You Lost :(",True,black)

        Window.blit(text,(100,200))

        velx = 0
        
    elif recChar.colliderect(recspike3) or recChar.colliderect(recspike33):
        notDead = True

        font = pygame.font.SysFont("Arial", 100,True,False)

        text = font.render("You Lost :(",True,black)

        Window.blit(text,(100,200))

        velx = 0

    elif recChar.colliderect(recspike4) or recChar.colliderect(recspike44):
        notDead = True

        font = pygame.font.SysFont("Arial", 100,True,False)

        text = font.render("You Lost :(",True,black)

        Window.blit(text,(100,200))

        velx = 0

        ##Moving enemy
   
    if (enemyx+velx>350):
        velx = -3
    if (enemyx+velx <150):
        velx = 3
    enemyx = enemyx+velx;

    recenemy= pygame.Rect(enemyx+7,enemyy+3,30,30)

    if recChar.colliderect(recenemy):

        notDead = True

        font = pygame.font.SysFont("Arial", 100,True,False)

        text = font.render("You Lost :(",True,black)

        Window.blit(text,(100,200))

        velx = 0
    
##    pygame.draw.rect(Window,white,((214,295,32,5)))
##    pygame.draw.rect(Window,white,((218,290,25,5)))
##    pygame.draw.rect(Window,white,((222,285,18,5)))
##    pygame.draw.rect(Window,white,((228,270,5,15)))
        
    Window.blit(TA,(0,0))
    Window.blit(menu,(0,50))
    Window.blit(nextt,(0,100))
    Window.blit(bad[0],(enemyx, enemyy))
    Window.blit(pic,(x,y))
    pygame.display.update()
    fpsClock.tick(FPS)


