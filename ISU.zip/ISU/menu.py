#**********************************************************
# Program : Pygame game
# Author : Vanessa Vo
# Due Date : 11/28/18
# Description : menu screen 
#**********************************************************


##Window
import pygame
import sys
from pygame.locals import*
pygame.init()

FPS = 40
fpsClock = pygame.time.Clock()

Window = pygame.display.set_mode((600,600))

##Colours

white = 255,255,255

##Level 1 button

L1 = pygame.image.load("button_level.png")

Window.blit(L1,(250,270))

##Level 2 button

L2 = pygame.image.load("button_level2.png")

Window.blit(L2,(250,370))

####Level 3 button
##
##L3 = pygame.image.load("button_level3.png")
##
##Window.blit(L3,(250,470))

##pygame.draw.rect(Window,white,(250,370,165,63))
##

##pygame.draw.rect(Window,white,(250,270,165,63))
#Game Loop

while True:

    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit

        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse =(("%d,%d")%event.pos)
            a,b = mouse.split(",")
            a = int(a)
            b=int(b)
            print(a)
            print(b)
            position = pygame.mouse.get_pos()
            print(position)

            if a>250 and b>271 and a<415 and b<334:
                exec(open("ISU.level1.py").read())

            if a>250 and b>367 and a<413 and b<436:
                exec(open("ISU.level2.py").read())
##
##            if a>241 and b>470 and a<416 and b<542:
##                execfile("ISUlevel3.py")

    pygame.display.update()
    fpsClock.tick(FPS)
        


